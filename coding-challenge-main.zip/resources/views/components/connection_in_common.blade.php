<div class="p-2 shadow rounded mt-2  text-white bg-dark">{{ $connection_in_common->name }} - {{ $connection_in_common->email }}</div>
