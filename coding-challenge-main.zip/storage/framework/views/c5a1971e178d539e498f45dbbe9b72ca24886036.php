
<div class="my-2 shadow  text-white bg-dark p-1" id="suggestion_<?php echo e($suggestion->id); ?>">
    <div class="d-flex justify-content-between">
        <table class="ms-1">
            <td class="align-middle"><?php echo e($suggestion->name); ?></td>
            <td class="align-middle"> - </td>
            <td class="align-middle"><?php echo e($suggestion->email); ?></td>
            <td class="align-middle">
        </table>
        <div>
            <button id="create_request_btn_<?php echo e($suggestion->id); ?>" class="btn btn-primary me-1"
                    onclick="sendRequest(<?php echo e(\Illuminate\Support\Facades\Auth::id()); ?>, <?php echo e($suggestion->id); ?>)">
                Connect</button>
        </div>
    </div>
</div>
<?php /**PATH E:\laragon\www\coding-challenge-main\coding-challenge-main\resources\views/components/suggestion.blade.php ENDPATH**/ ?>