<div class="row justify-content-center">
  <div class="col-12">
    <div class="card shadow  text-white bg-dark">
      <div class="card-header"><?php echo e(__('Dashboard')); ?></div>
      <div class="card-body">
        <?php if(session('status')): ?>
          <div class="alert alert-success" role="alert">
            <?php echo e(session('status')); ?>

          </div>
        <?php endif; ?>
        <?php echo e(__('You are logged in!')); ?>

      </div>
    </div>
  </div>
</div><?php /**PATH E:\laragon\www\coding-challenge-main\coding-challenge-main\resources\views/components/dashboard.blade.php ENDPATH**/ ?>