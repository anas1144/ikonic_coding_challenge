<div class="my-2 shadow text-white bg-dark p-1" id="connection_<?php echo e($connection->id); ?>">
    <div class="d-flex justify-content-between">
        <table class="ms-1">
            <td class="align-middle"><?php echo e($connection->name); ?></td>
            <td class="align-middle"> -</td>
            <td class="align-middle"><?php echo e($connection->email); ?></td>
            <td class="align-middle">
        </table>
        <div>
            <button
                onclick="getConnectionsInCommon(<?php echo e(\Illuminate\Support\Facades\Auth::id()); ?>, <?php echo e($connection->id); ?>)"
                style="width: 220px"
                id="get_connections_in_common_<?php echo e($connection->id); ?>"
                class="btn btn-primary <?php echo e($connection->connectionInCommon->count() == 0 ? 'disabled':''); ?>"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#collapse_<?php echo e($connection->id); ?>"
                aria-expanded="false"
                aria-controls="collapseExample">
                Connections in common (<?php echo e($connection->connectionInCommon->count()); ?>)
            </button>
            <button id="create_request_btn_<?php echo e($connection->id); ?>" class="btn btn-danger me-1"
                    onclick="removeConnection(<?php echo e(\Illuminate\Support\Facades\Auth::id()); ?>, <?php echo e($connection->id); ?>)"
            >Remove Connection
            </button>
        </div>

    </div>
    <div class="collapse" id="collapse_<?php echo e($connection->id); ?>">

        <div id="content_<?php echo e($connection->id); ?>" class="p-2">
            
        </div>
        <div id="connections_in_common_skeletons_<?php echo e($connection->id); ?>">
            
            <?php for($i = 0; $i < 10; $i++): ?>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.skeleton','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('skeleton'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            <?php endfor; ?>
        </div>
        <div class="d-flex justify-content-center w-100 py-2">
            <button
                onclick="getMoreConnectionsInCommon(<?php echo e(\Illuminate\Support\Facades\Auth::id()); ?>, <?php echo e($connection->id); ?>)"
                data-skipCounter="10"
                class="btn btn-sm btn-primary d-none"
                id="load_more_connections_in_common_<?php echo e($connection->id); ?>">Load
                more
            </button>
        </div>
    </div>
</div>
<?php /**PATH E:\laragon\www\coding-challenge-main\coding-challenge-main\resources\views/components/connection.blade.php ENDPATH**/ ?>