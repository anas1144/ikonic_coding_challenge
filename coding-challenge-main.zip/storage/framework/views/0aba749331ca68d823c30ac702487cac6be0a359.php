<div class="my-2 shadow text-white bg-dark p-1" id="request_<?php echo e($request->id); ?>">
  <div class="d-flex justify-content-between">
    <table class="ms-1">
        <td class="align-middle"><?php echo e($request->name); ?></td>
        <td class="align-middle"> - </td>
        <td class="align-middle"><?php echo e($request->email); ?></td>
      <td class="align-middle">
    </table>
    <div>
      <?php if($mode == 'sent'): ?>
        <button id="cancel_request_btn_<?php echo e($request->id); ?>" class="btn btn-danger me-1"
          onclick="deleteRequest(<?php echo e(\Illuminate\Support\Facades\Auth::id()); ?>, <?php echo e($request->id); ?>)">
            Withdraw Request</button>
      <?php else: ?>
        <button id="accept_request_btn_<?php echo e($request->id); ?>" class="btn btn-primary me-1"
          onclick="acceptRequest(<?php echo e(\Illuminate\Support\Facades\Auth::id()); ?>, <?php echo e($request->id); ?>)">
            Accept</button>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php /**PATH E:\laragon\www\coding-challenge-main\coding-challenge-main\resources\views/components/request.blade.php ENDPATH**/ ?>